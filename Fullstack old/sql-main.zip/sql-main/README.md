🛢️ MySQL is one of the world's best-known open-source databases. It was developed by numerous contributors over the years and has become an essential technology for anyone working with backend development. With it, we learn where our data is stored, how it's saved, and how such a widely used database can maintain information for so many years.

🛢️ SQL, on the other hand, is a Structured Query Language. It's an extremely powerful language that allows you to create structures within the database and manipulate the data stored there. It's fascinating how something seemingly simple makes it possible to store large amounts of user information for long periods. Many older systems still have huge preserved backups, and that always impresses me.

🛢️ And of course, I couldn't fail to mention at least the basics here, in case you—dear visitor—want to learn a little more about SQL and MySQL.

🛢️ DDL (Data Definition Language) is used to create the database structures that will house the information. 🛢️ **DML (Data Manipulation Language)** is used to manipulate and maintain data within these structures.

🛢️ Within the structures of a database, we have:

🛢️ the **Database**, where the objects that store data are located;

🛢️ the **Table**, which stores records in columns;

🛢️ the **Primary Key**, which identifies each record;

🛢️ and the **Foreign Key**, which creates relationships between tables.

🛢️ Some common MySQL commands:
<br>
CREATE DATABASE name; -- Creates the database<br>
CREATE TABLE name (...); -- Creates a table<br>
ALTER TABLE name ...; -- Alters an existing table<br>
<br>
SELECT * FROM table; -- Selects data<br>
INSERT INTO table (...) VALUES (...); -- Insert data<br>
UPDATE table SET ... WHERE ...; -- Update table<br>
DELETE FROM table WHERE ...; -- Delete records<br>
